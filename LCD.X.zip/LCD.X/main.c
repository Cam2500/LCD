/* 
 * File:   main.c
 * Author: Camilo
 *
 * Created on 28 de Marzo de 2023, 12:37 PM
 */

#include <stdio.h>
#include "xc.h"
#define FCY 8000000
#include <libpic30.h> 
#include "mcc_generated_files/system.h"
#include "lcd.h"
#include "math.h"

int bandera;



int main(void) {
    AD1PCFG = 0xFFFF;
    
    TRISAbits.TRISA0=1;
    TRISAbits.TRISA1=1;
    TRISAbits.TRISA2=1;
    TRISB = 0;
    
    
    // initialize the device
    SYSTEM_Initialize();
    LCD_Initialize();
    DisplayClr();
    TMR1_Start();
    while(1){
        if (bandera == 1){
            LCDGoto(0,0);
            LCDPutStr("Prueba dos");
            LCDGoto(0,1);
            LCDPutStr("Prueba dos");
            
        }
        if (bandera == 0){
            LCDGoto(0,0);
            LCDPutStr("Prueba uno");
            LCDGoto(0,1);
            LCDPutStr("Prueba uno");
            
        }
    }
    return 1;
}

void TMR1_CallBack(){
    bandera=!bandera;
    _T1IE=0;
    TMR1_Start();
}
